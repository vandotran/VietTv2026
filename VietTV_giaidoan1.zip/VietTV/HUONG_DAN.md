# VietTV+ – Giai đoạn 1 (TV trực tiếp)

## 1. Mở và chạy thử
1. Cài Android Studio (bản Koala trở lên), giải nén file zip.
2. File > Open > chọn thư mục `VietTV`, chờ Gradle sync (lần đầu cần mạng).
3. Bật "Gỡ lỗi USB" trên điện thoại, cắm cáp, bấm nút Run ▶.

## 2. Build APK cài đặt
Build > Build Bundle(s) / APK(s) > Build APK(s) → file nằm ở `app/build/outputs/apk/debug/app-debug.apk`.
Copy sang điện thoại, mở lên và cho phép cài từ nguồn không xác định.

## 3. Thêm / sửa kênh TV (không cần sửa code)
Mỗi kênh là một dòng trong `app/src/main/assets/channels.json`:
{ "id": "dong-nai-dntv", "name": "Đồng Nai DNTV", "province": "Đồng Nai", "region": "nam",
  "group": "diaphuong", "category": "Địa phương", "logo": "", "url": "https://link-hop-phap/live.m3u8" }
- region: bac | trung | nam (kênh quốc gia để "")
- group: quocgia | trunguong | diaphuong | chuyenbiet
- id phải duy nhất. Dán link .m3u8 hoặc .mp4 hợp pháp của bạn vào "url".
Không muốn build lại: chép file đã sửa vào `Android/data/com.viettv.plus/files/channels.json`
trên điện thoại, app sẽ ưu tiên file này.

## 4. Thư viện và quyền
Xem `app/build.gradle.kts` (Compose, Media3 ExoPlayer + HLS + UI, Room + KSP).
Quyền trong AndroidManifest: INTERNET, ACCESS_NETWORK_STATE. Có `usesCleartextTraffic` để phát link http.

## 5. Lỗi thường gặp
- Kênh báo "đang bảo trì": link trống/hết hạn/chặn theo vùng. Bấm Thử lại hoặc thay link.
- Link http không phát: đã bật cleartext; nếu vẫn lỗi, kiểm tra link bằng VLC trên máy tính.
- Gradle sync lỗi: kiểm tra mạng, JDK 17 (Settings > Build Tools > Gradle > Gradle JDK).
- Không có file gradlew: Android Studio sẽ tự tạo khi sync.
