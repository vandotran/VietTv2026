package com.viettv.plus.ui

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.viettv.plus.MainActivity
import com.viettv.plus.TvViewModel
import com.viettv.plus.data.Channel

@Composable
fun PlayerScreen(vm: TvViewModel, ch: Channel, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val act = ctx as Activity
    val fav by vm.favIds.collectAsStateWithLifecycle()
    var error by remember(ch.id) { mutableStateOf(ch.url.isBlank()) }   // link trống = coi như bảo trì
    var retry by remember { mutableIntStateOf(0) }
    var full by remember { mutableStateOf(false) }

    // ExoPlayer: tạo lại khi đổi kênh hoặc bấm Thử lại; HLS (.m3u8) và .mp4 tự nhận theo link
    val player = remember(ch.id, retry) {
        // Gửi kèm Referer / User-Agent nếu playlist yêu cầu; cho phép chuyển hướng http -> https
        val http = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true)
            .setUserAgent(ch.userAgent.ifBlank { "Mozilla/5.0 (Linux; Android 10)" })
            .apply { if (ch.referrer.isNotBlank()) setDefaultRequestProperties(mapOf("Referer" to ch.referrer)) }
        ExoPlayer.Builder(ctx).setMediaSourceFactory(DefaultMediaSourceFactory(ctx).setDataSourceFactory(http)).build().apply {
            if (ch.url.isNotBlank()) {
                addListener(object : Player.Listener {
                    override fun onPlayerError(e: PlaybackException) { error = true }
                })
                setMediaItem(MediaItem.fromUri(ch.url)); prepare(); playWhenReady = true
            }
        }
    }
    DisposableEffect(player) {
        MainActivity.playerActive = true
        onDispose { MainActivity.playerActive = false; player.release() }
    }
    fun setFull(v: Boolean) {
        full = v
        act.requestedOrientation = if (v) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        val c = WindowCompat.getInsetsController(act.window, act.window.decorView)
        if (v) c.hide(WindowInsetsCompat.Type.systemBars()) else c.show(WindowInsetsCompat.Type.systemBars())
    }
    fun close() { if (full) setFull(false); onClose() }
    BackHandler { close() }

    // Vuốt dọc: nửa trái = độ sáng, nửa phải = âm lượng
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    var bright by remember { mutableFloatStateOf(0.5f) }
    var vol by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Box(
            (if (full) Modifier.fillMaxSize() else Modifier.fillMaxWidth().aspectRatio(16 / 9f))
                .pointerInput(Unit) {
                    detectVerticalDragGestures { change, dy ->
                        val delta = -dy / size.height
                        if (change.position.x < size.width / 2) {
                            bright = (bright + delta).coerceIn(0.05f, 1f)
                            act.window.attributes = act.window.attributes.also { it.screenBrightness = bright }
                        } else {
                            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                            vol = (vol + delta * max).coerceIn(0f, max.toFloat())
                            am.setStreamVolume(AudioManager.STREAM_MUSIC, vol.toInt(), 0)
                        }
                    }
                }
        ) {
            if (!error) AndroidView({ PlayerView(it).apply { this.player = player; useController = true } }, Modifier.fillMaxSize())
            else Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Kênh đang bảo trì, thử lại sau", color = Color.White)
                if (ch.url.isNotBlank()) TextButton({ error = false; retry++ }) { Text("Thử lại") }
            }
            Row(Modifier.align(Alignment.TopStart).fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton({ close() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Quay lại", tint = Color.White) }
                Text(ch.name, color = Color.White, modifier = Modifier.weight(1f))
                IconButton({ vm.toggleFav(ch) }) {
                    Icon(Icons.Default.Star, "Yêu thích", tint = if (ch.id in fav) Color(0xFFFFC107) else Color.White)
                }
                IconButton({ setFull(!full) }) { Icon(Icons.Default.Fullscreen, "Toàn màn hình", tint = Color.White) }
            }
        }
        if (!full) {
            val related = remember(ch.id) { vm.related(ch) }
            Text(if (error) "Gợi ý kênh khác" else "Kênh cùng khu vực", Modifier.padding(12.dp), color = Color.White)
            LazyColumn {
                items(related, key = { it.id }) { c ->
                    Text(c.name + if (c.url.isBlank()) "  (chưa có link)" else "", color = Color.White,
                        modifier = Modifier.fillMaxWidth().clickable { vm.play(c) }.padding(14.dp))
                }
            }
        }
    }
}
