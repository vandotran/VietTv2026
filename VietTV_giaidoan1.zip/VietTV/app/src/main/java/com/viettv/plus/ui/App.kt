package com.viettv.plus.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.viettv.plus.TvViewModel
import com.viettv.plus.data.Channel

val Red = Color(0xFFE50914)

@Composable
fun AppRoot(vm: TvViewModel = viewModel()) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Color(0xFF0B0B0F), surface = Color(0xFF16161C))) {
        val selected by vm.selected.collectAsStateWithLifecycle()
        var tab by remember { mutableIntStateOf(0) }
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            if (selected != null) {
                PlayerScreen(vm, selected!!) { vm.selected.value = null }
            } else Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                bottomBar = {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                        listOf("Trang chủ" to Icons.Default.Home, "TV Trực tiếp" to Icons.Default.Tv, "Phim" to Icons.Default.Movie)
                            .forEachIndexed { i, (t, ic) ->
                                NavigationBarItem(selected = tab == i, onClick = { tab = i },
                                    icon = { Icon(ic, t) }, label = { Text(t) })
                            }
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad).fillMaxSize()) {
                    when (tab) {
                        0 -> HomeTab(vm) { tab = 1 }
                        1 -> TvTab(vm)
                        else -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                            Text("Phần Phim (WebView) sẽ có ở giai đoạn 2", color = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

// ---------------- TRANG CHỦ ----------------
@Composable
fun HomeTab(vm: TvViewModel, openTv: () -> Unit) {
    val his by vm.historyIds.collectAsStateWithLifecycle()
    val fav by vm.favIds.collectAsStateWithLifecycle()
    val recent = his.mapNotNull { id -> vm.channels.find { it.id == id } }
    LazyColumn(contentPadding = PaddingValues(vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        item { Text("VietTV+", Modifier.padding(horizontal = 16.dp), color = Red, style = MaterialTheme.typography.headlineLarge) }
        item { Row("Tiếp tục xem", recent, vm) }
        item { Row("Kênh yêu thích", vm.channels.filter { it.id in fav }, vm) }
        item { Row("Kênh quốc gia", vm.channels.filter { it.group == "quocgia" }, vm) }
        item { Row("Đài Miền Bắc", vm.channels.filter { it.region == "bac" }, vm) }
        item { Row("Đài Miền Trung", vm.channels.filter { it.region == "trung" }, vm) }
        item { Row("Đài Miền Nam", vm.channels.filter { it.region == "nam" }, vm) }
    }
}

@Composable
private fun Row(title: String, list: List<Channel>, vm: TvViewModel) {
    if (list.isEmpty()) return
    Column {
        Text(title, Modifier.padding(horizontal = 16.dp, vertical = 6.dp), style = MaterialTheme.typography.titleMedium)
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.id }) { c ->
                Column(Modifier.width(110.dp).clip(RoundedCornerShape(10.dp)).clickable { vm.play(c) }
                    .background(MaterialTheme.colorScheme.surface).padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Logo(c, 48)
                    Text(c.name, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

@Composable
fun Logo(c: Channel, size: Int) = Box(Modifier.size(size.dp).clip(RoundedCornerShape(8.dp)).background(Red.copy(alpha = .85f)), Alignment.Center) {
    Text(c.name.take(3).uppercase(), color = Color.White, style = MaterialTheme.typography.labelMedium)
}

// ---------------- TV TRỰC TIẾP ----------------
private val filters = listOf("all" to "Tất cả", "quocgia" to "Quốc gia", "trunguong" to "Trung ương", "bac" to "Miền Bắc",
    "trung" to "Miền Trung", "nam" to "Miền Nam", "chuyenbiet" to "Chuyên biệt", "fav" to "Yêu thích", "history" to "Lịch sử")

@Composable
fun TvTab(vm: TvViewModel) {
    val list by vm.shown.collectAsStateWithLifecycle()
    val q by vm.query.collectAsStateWithLifecycle()
    val f by vm.filter.collectAsStateWithLifecycle()
    val fav by vm.favIds.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(q, { vm.query.value = it }, Modifier.fillMaxWidth().padding(12.dp), singleLine = true,
            placeholder = { Text("Tìm kênh, tên đài, tỉnh...") }, leadingIcon = { Icon(Icons.Default.Search, null) })
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filters) { (k, t) -> FilterChip(f == k, { vm.filter.value = k }, { Text(t) }) }
        }
        if (list.isEmpty()) Box(Modifier.fillMaxSize(), Alignment.Center) { Text("Không có kênh phù hợp", color = Color.Gray) }
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list, key = { it.id }) { c ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surface)
                    .clickable { vm.play(c) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Logo(c, 44)
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(c.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(listOf(c.province, c.category).filter { it.isNotBlank() }.joinToString(" • ") +
                            if (c.url.isBlank()) " • chưa có link" else "", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                    }
                    IconButton({ vm.toggleFav(c) }) {
                        if (c.id in fav) Icon(Icons.Default.Star, "Bỏ yêu thích", tint = Color(0xFFFFC107))
                        else Icon(Icons.Outlined.StarBorder, "Yêu thích")
                    }
                }
            }
        }
    }
}
