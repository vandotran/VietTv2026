package com.viettv.plus.data

import android.content.Context
import org.json.JSONArray
import java.io.File
import java.text.Normalizer

/** Một kênh TV. Thêm/bớt kênh chỉ cần sửa channels.json. */
data class Channel(
    val id: String, val name: String, val province: String,
    val region: String,   // bac | trung | nam | "" (kênh quốc gia)
    val group: String,    // quocgia | trunguong | diaphuong | chuyenbiet
    val category: String, val logo: String, val url: String
)

fun String.noAccent(): String =
    Normalizer.normalize(this, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
        .replace('đ', 'd').replace('Đ', 'D').lowercase()

object ChannelRepository {
    /** Ưu tiên file ngoài (getExternalFilesDir/channels.json) để sửa không cần build lại; không có thì dùng file trong assets. */
    fun load(ctx: Context): List<Channel> {
        val ext = File(ctx.getExternalFilesDir(null), "channels.json")
        val text = if (ext.exists()) ext.readText() else ctx.assets.open("channels.json").bufferedReader().readText()
        val arr = JSONArray(text)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Channel(o.getString("id"), o.getString("name"), o.optString("province"), o.optString("region"),
                o.optString("group"), o.optString("category"), o.optString("logo"), o.optString("url"))
        }
    }
}
