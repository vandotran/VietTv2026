package com.viettv.plus.data

import android.content.Context
import org.json.JSONArray
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer

/** Một kênh TV. Thêm/bớt kênh chỉ cần sửa channels.json. */
data class Channel(
    val id: String, val name: String, val province: String,
    val region: String,   // bac | trung | nam | "" (kênh quốc gia)
    val group: String,    // quocgia | trunguong | diaphuong | chuyenbiet
    val category: String, val logo: String, val url: String,
    val referrer: String = "", val userAgent: String = ""   // một số link playlist yêu cầu header
)

fun String.noAccent(): String =
    Normalizer.normalize(this, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
        .replace('đ', 'd').replace('Đ', 'D').lowercase()

object ChannelRepository {
    /** Ưu tiên file ngoài (getExternalFilesDir/channels.json) để sửa không cần build lại; không có thì dùng file trong assets. */
    fun load(ctx: Context): List<Channel> {
        val ext = File(ctx.getExternalFilesDir(null), "channels.json")
        val text = if (ext.exists()) ext.readText() else ctx.assets.open("channels.json").bufferedReader().readText()
        val arr = JSONArray(text)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Channel(o.getString("id"), o.getString("name"), o.optString("province"), o.optString("region"),
                o.optString("group"), o.optString("category"), o.optString("logo"), o.optString("url"))
        }
    }
}

/** Nguồn chính: playlist M3U trong assets/playlists.txt (dòng 1 = chính, các dòng sau = dự phòng). */
object PlaylistRepository {
    private fun urls(ctx: Context): List<String> {
        val ext = File(ctx.getExternalFilesDir(null), "playlists.txt")
        val t = if (ext.exists()) ext.readText() else ctx.assets.open("playlists.txt").bufferedReader().readText()
        return t.lines().map { it.trim() }.filter { it.startsWith("http") }
    }
    private fun cacheFile(ctx: Context) = File(ctx.filesDir, "playlist.m3u")

    /** Bản đã lưu lần tải trước (dùng khi mất mạng). */
    fun cached(ctx: Context, base: List<Channel>): List<Channel>? =
        cacheFile(ctx).takeIf { it.exists() }?.let { parse(it.readText(), base) }?.takeIf { it.isNotEmpty() }

    /** Thử link chính, lỗi thì sang link dự phòng. Gọi trong luồng IO. */
    fun download(ctx: Context, base: List<Channel>): List<Channel>? {
        for (u in urls(ctx)) try {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 10000; c.readTimeout = 20000; c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "Mozilla/5.0")
            val t = c.inputStream.bufferedReader().use { it.readText() }
            val l = parse(t, base)
            if (l.isNotEmpty()) { cacheFile(ctx).writeText(t); return l }
        } catch (_: Exception) { }
        return null
    }

    /** Đọc M3U: #EXTINF (tên, logo, nhóm), #EXTVLCOPT (referrer, user-agent), dòng URL. Tự đoán tỉnh/miền theo tên đài. */
    fun parse(text: String, base: List<Channel>): List<Channel> {
        val places = base.filter { it.group == "diaphuong" }.map { it.province to it.region }.distinct()
        val alias = mapOf("htv" to ("TP.HCM" to "nam"), "thvl" to ("Vĩnh Long" to "nam"))
        val attrRe = Regex("([\\w-]+)=\"([^\"]*)\"")
        val used = HashSet<String>(); val out = ArrayList<Channel>()
        var name = ""; var attrs = emptyMap<String, String>(); var ref = ""; var ua = ""; var grp = ""
        for (raw in text.lineSequence()) {
            val l = raw.trim()
            when {
                l.startsWith("#EXTINF") -> {
                    attrs = attrRe.findAll(l).associate { it.groupValues[1] to it.groupValues[2] }
                    name = l.substringAfterLast(',').trim(); ref = ""; ua = ""; grp = attrs["group-title"].orEmpty()
                }
                l.startsWith("#EXTVLCOPT:http-referrer=") -> ref = l.substringAfter("=")
                l.startsWith("#EXTVLCOPT:http-user-agent=") -> ua = l.substringAfter("=")
                l.startsWith("#EXTGRP:") -> grp = l.substringAfter(":")
                l.isNotEmpty() && !l.startsWith("#") -> if (name.isNotEmpty()) {
                    val key = name.noAccent()
                    val place = places.find { key.contains(it.first.noAccent()) }
                        ?: alias.entries.find { key.split(Regex("[^a-z0-9]+")).contains(it.key) }?.value
                    val group = when {
                        key.startsWith("vtv") && place == null -> "quocgia"
                        place != null -> "diaphuong"
                        grp.lowercase() !in setOf("", "undefined") -> "chuyenbiet"
                        else -> "trunguong"
                    }
                    var id = attrs["tvg-id"].orEmpty().ifBlank { key.replace(Regex("[^a-z0-9]+"), "-") }
                    if (!used.add(id)) { var n = 2; while (!used.add("$id-$n")) n++; id = "$id-$n" }
                    out.add(Channel(id, name, place?.first ?: "Việt Nam", place?.second ?: "", group,
                        grp.ifBlank { "Tổng hợp" }, attrs["tvg-logo"].orEmpty(), l, ref, ua))
                    name = ""
                }
            }
        }
        return out
    }
}
