package com.viettv.plus

import android.app.PictureInPictureParams
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.viettv.plus.ui.AppRoot

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppRoot() }
    }
    /** Bấm Home khi đang xem TV -> tự vào chế độ Picture-in-Picture. */
    override fun onUserLeaveHint() {
        if (playerActive && Build.VERSION.SDK_INT >= 26)
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
    }
    companion object { @Volatile var playerActive = false }
}
