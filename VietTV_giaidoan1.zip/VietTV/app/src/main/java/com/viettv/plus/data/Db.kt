package com.viettv.plus.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "favorites") data class FavoriteE(@PrimaryKey val channelId: String)
@Entity(tableName = "history") data class HistoryE(@PrimaryKey val channelId: String, val watchedAt: Long)

@Entity(tableName = "links") data class LinkE(@PrimaryKey val channelId: String, val url: String)

@Dao interface TvDao {
    @Query("SELECT * FROM links") fun links(): Flow<List<LinkE>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun setLink(l: LinkE)
    @Query("DELETE FROM links WHERE channelId = :id") suspend fun delLink(id: String)
    @Query("SELECT channelId FROM favorites") fun favorites(): Flow<List<String>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addFav(f: FavoriteE)
    @Query("DELETE FROM favorites WHERE channelId = :id") suspend fun delFav(id: String)
    @Query("SELECT channelId FROM history ORDER BY watchedAt DESC LIMIT 50") fun history(): Flow<List<String>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addHistory(h: HistoryE)
}

@Database(entities = [FavoriteE::class, HistoryE::class, LinkE::class], version = 2, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): TvDao
    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context) = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "viettv.db").fallbackToDestructiveMigration().build().also { inst = it }
        }
    }
}
