package com.viettv.plus.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "favorites") data class FavoriteE(@PrimaryKey val channelId: String)
@Entity(tableName = "history") data class HistoryE(@PrimaryKey val channelId: String, val watchedAt: Long)

@Dao interface TvDao {
    @Query("SELECT channelId FROM favorites") fun favorites(): Flow<List<String>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addFav(f: FavoriteE)
    @Query("DELETE FROM favorites WHERE channelId = :id") suspend fun delFav(id: String)
    @Query("SELECT channelId FROM history ORDER BY watchedAt DESC LIMIT 50") fun history(): Flow<List<String>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addHistory(h: HistoryE)
}

@Database(entities = [FavoriteE::class, HistoryE::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): TvDao
    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context) = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "viettv.db").build().also { inst = it }
        }
    }
}
