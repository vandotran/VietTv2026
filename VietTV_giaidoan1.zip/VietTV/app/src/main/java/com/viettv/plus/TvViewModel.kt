package com.viettv.plus

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.viettv.plus.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class TvViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()
    private val base: List<Channel> = ChannelRepository.load(app)   // danh sách có sẵn (dự phòng offline)
    val channelsFlow = MutableStateFlow(base)
    val channels: List<Channel> get() = channelsFlow.value
    val status = MutableStateFlow("")

    init { refresh() }
    /** Tải playlist M3U (link chính -> dự phòng); lỗi thì dùng bản đã lưu hoặc danh sách có sẵn. */
    fun refresh() {
        viewModelScope.launch(Dispatchers.IO) {
            status.value = "Đang tải playlist..."
            val app = getApplication<Application>()
            PlaylistRepository.cached(app, base)?.let { channelsFlow.value = it }
            val r = PlaylistRepository.download(app, base)
            if (r != null) { channelsFlow.value = r; status.value = "Đã tải ${r.size} kênh từ playlist" }
            else status.value = "Không tải được playlist, đang dùng dữ liệu đã lưu"
        }
    }
    val query = MutableStateFlow("")
    val filter = MutableStateFlow("all")   // all|quocgia|trunguong|bac|trung|nam|chuyenbiet|fav|history
    val selected = MutableStateFlow<Channel?>(null)

    val favIds = dao.favorites().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val historyIds = dao.history().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Danh sách hiển thị sau khi tìm kiếm + lọc (tìm không dấu: "ha noi" ra "Hà Nội"). */
    /** Link người dùng tự nhập trong app (ưu tiên hơn link trong channels.json). */
    val links = dao.links().map { l -> l.associate { it.channelId to it.url } }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())
    fun resolve(c: Channel): Channel = links.value[c.id]?.takeIf { it.isNotBlank() }?.let { c.copy(url = it) } ?: c
    fun setLink(c: Channel, url: String) { viewModelScope.launch(Dispatchers.IO) { if (url.isBlank()) dao.delLink(c.id) else dao.setLink(LinkE(c.id, url.trim())) } }

    val shown = combine(query, filter, favIds, historyIds, combine(channelsFlow, links) { c, l -> c to l }) { q, f, fav, his, data ->
        val (channels, lk) = data
        val base = when (f) {
            "quocgia", "trunguong", "chuyenbiet" -> channels.filter { it.group == f }
            "bac", "trung", "nam" -> channels.filter { it.region == f }
            "fav" -> channels.filter { it.id in fav }
            "history" -> his.mapNotNull { id -> channels.find { it.id == id } }
            else -> channels
        }
        val k = q.noAccent().trim()
        (if (k.isEmpty()) base else base.filter { (it.name + " " + it.province).noAccent().contains(k) })
            .map { c -> lk[c.id]?.takeIf { it.isNotBlank() }?.let { c.copy(url = it) } ?: c }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, base)

    fun play(c: Channel) {
        selected.value = resolve(c)
        viewModelScope.launch(Dispatchers.IO) { dao.addHistory(HistoryE(c.id, System.currentTimeMillis())) }
    }
    fun toggleFav(c: Channel) = viewModelScope.launch(Dispatchers.IO) {
        if (c.id in favIds.value) dao.delFav(c.id) else dao.addFav(FavoriteE(c.id))
    }
    /** Gợi ý kênh khác cùng tỉnh khi kênh lỗi; nếu không có thì lấy kênh cùng nhóm đang có link. */
    fun related(c: Channel): List<Channel> =
        channels.filter { it.province == c.province && it.id != c.id }.map { resolve(it) }.ifEmpty {
            channels.map { resolve(it) }.filter { it.group == c.group && it.id != c.id && it.url.isNotBlank() }.take(6)
        }
}
