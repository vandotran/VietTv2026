package com.viettv.plus

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.viettv.plus.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class TvViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()
    val channels: List<Channel> = ChannelRepository.load(app)
    val query = MutableStateFlow("")
    val filter = MutableStateFlow("all")   // all|quocgia|trunguong|bac|trung|nam|chuyenbiet|fav|history
    val selected = MutableStateFlow<Channel?>(null)

    val favIds = dao.favorites().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val historyIds = dao.history().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Danh sách hiển thị sau khi tìm kiếm + lọc (tìm không dấu: "ha noi" ra "Hà Nội"). */
    val shown = combine(query, filter, favIds, historyIds) { q, f, fav, his ->
        val base = when (f) {
            "quocgia", "trunguong", "chuyenbiet" -> channels.filter { it.group == f }
            "bac", "trung", "nam" -> channels.filter { it.region == f }
            "fav" -> channels.filter { it.id in fav }
            "history" -> his.mapNotNull { id -> channels.find { it.id == id } }
            else -> channels
        }
        val k = q.noAccent().trim()
        if (k.isEmpty()) base else base.filter { (it.name + " " + it.province).noAccent().contains(k) }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, channels)

    fun play(c: Channel) {
        selected.value = c
        viewModelScope.launch(Dispatchers.IO) { dao.addHistory(HistoryE(c.id, System.currentTimeMillis())) }
    }
    fun toggleFav(c: Channel) = viewModelScope.launch(Dispatchers.IO) {
        if (c.id in favIds.value) dao.delFav(c.id) else dao.addFav(FavoriteE(c.id))
    }
    /** Gợi ý kênh khác cùng tỉnh khi kênh lỗi; nếu không có thì lấy kênh cùng nhóm đang có link. */
    fun related(c: Channel): List<Channel> =
        channels.filter { it.province == c.province && it.id != c.id }.ifEmpty {
            channels.filter { it.group == c.group && it.id != c.id && it.url.isNotBlank() }.take(6)
        }
}
